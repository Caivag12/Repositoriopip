from setuptools import setup, find_packages

setup(
    name='Repositoiopip',
    version='0.1',
    packages=find_packages(),
    description='Un repositorio de ejemplo para demostrar la configuración de setup.py',
    author='Ivan Aguirre',
    author_email='carlosivan291199@gmail.com',
    url='https://github.com/Caivag12/Repositoriopip',
    
)
